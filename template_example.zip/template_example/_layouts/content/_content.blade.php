@if($content['title_visibility'])
        <h2 class="black">{!! $content['title'] !!}</h2>
@endif
    {!! $content['content'] !!}
